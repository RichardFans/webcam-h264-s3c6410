#ifndef __SAMSUNG_SYSLSI_APDEV_DEMO_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_DEMO_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif


int Demo(int argc, char **argv);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_DEMO_TEST_H__ */

