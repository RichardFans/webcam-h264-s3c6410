#ifndef __SAMSUNG_SYSLSI_APDEV_LINE_BUF_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_LINE_BUF_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif

int Test_H263_Decoder_Line_Buffer(int argc, char **argv);
int Test_H264_Decoder_Line_Buffer(int argc, char **argv);
int Test_MPEG4_Decoder_Line_Buffer(int argc, char **argv);
int Test_VC1_Decoder_Line_Buffer(int argc, char **argv);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_LINE_BUF_TEST_H__ */

