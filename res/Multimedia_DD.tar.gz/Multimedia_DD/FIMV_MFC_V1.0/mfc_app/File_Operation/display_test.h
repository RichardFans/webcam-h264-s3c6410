#ifndef __SAMSUNG_SYSLSI_APDEV_DISPLAY_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_DISPLAY_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif


int Test_Display(int argc, char **argv);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_DISPLAY_TEST_H__ */

