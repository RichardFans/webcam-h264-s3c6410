#ifndef __SAMSUNG_SYSLSI_APDEV_DISPLAY_OPTIMIZATION2_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_DISPLAY_OPTIMIZATION2_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif


int Forlinx_Test_Display_Optimization2(int argc, char **argv, int lcdnum);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_DISPLAY_OPTIMIZATION2_TEST_H__ */

