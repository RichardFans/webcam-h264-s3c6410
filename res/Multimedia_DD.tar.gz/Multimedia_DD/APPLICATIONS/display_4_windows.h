#ifndef __SAMSUNG_SYSLSI_APDEV_TEST_DISPLAY_4_WINDOWS_H__
#define __SAMSUNG_SYSLSI_APDEV_TEST_DISPLAY_4_WINDOWS_H__


#ifdef __cplusplus
extern "C" {
#endif


int Forlinx_Test_Display_4_Windows(int argc, char **argv, int lcdnum);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_TEST_DISPLAY_4_WINDOWS_H__ */

