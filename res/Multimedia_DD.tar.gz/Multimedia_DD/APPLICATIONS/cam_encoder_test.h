#ifndef __SAMSUNG_SYSLSI_APDEV_CAM_ENCODING_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_CAM_ENCODING_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif


int Forlinx_Test_Cam_Encoding(int argc, char **argv, int lcdnum);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_CAM_ENCODING_TEST_H__ */

