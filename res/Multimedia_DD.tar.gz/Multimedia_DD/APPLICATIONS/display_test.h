#ifndef __SAMSUNG_SYSLSI_APDEV_DISPLAY_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_DISPLAY_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif


int Forlinx_Test_Display_H264(int argc, char **argv, int lcdnum);
int Forlinx_Test_Display_MPEG4(int argc, char **argv, int lcdnum);
int Forlinx_Test_Display_H263(int argc, char **argv, int lcdnum);
int Forlinx_Test_Display_VC1(int argc, char **argv, int lcdnum);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_DISPLAY_TEST_H__ */

