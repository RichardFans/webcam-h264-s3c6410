#ifndef __SAMSUNG_SYSLSI_APDEV_RING_BUF_TEST_H__
#define __SAMSUNG_SYSLSI_APDEV_RING_BUF_TEST_H__


#ifdef __cplusplus
extern "C" {
#endif


int Test_Decoder_Ring_Buffer(int argc, char **argv);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_RING_BUF_TEST_H__ */
