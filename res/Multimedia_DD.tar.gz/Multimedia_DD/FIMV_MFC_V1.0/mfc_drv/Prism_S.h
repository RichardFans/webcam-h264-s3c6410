#ifndef __SAMSUNG_SYSLSI_APDEV_PRISM_S_H__
#define __SAMSUNG_SYSLSI_APDEV_PRISM_S_H__

extern const unsigned short bit_code[40960];

#endif /* __SAMSUNG_SYSLSI_APDEV_PRISM_S_H__ */
