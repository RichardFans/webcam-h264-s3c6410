#ifndef __SAMSUNG_SYSLSI_APDEV_JPEG_DISPLAY_H__
#define __SAMSUNG_SYSLSI_APDEV_JPEG_DISPLAY_H__


#ifdef __cplusplus
extern "C" {
#endif


int Forlinx_Test_Jpeg_Display(int argc, char **argv, int lcdnum);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_JPEG_DISPLAY_H__ */
 
