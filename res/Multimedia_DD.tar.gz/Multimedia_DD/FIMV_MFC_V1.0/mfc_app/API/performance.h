#ifndef __SAMSUNG_SYSLSI_APDEV_PERFORMANCE_H__
#define __SAMSUNG_SYSLSI_APDEV_PERFORMANCE_H__


#ifdef __cplusplus
extern "C" {
#endif


unsigned int measureTime(struct timeval *start, struct timeval *stop);


#ifdef __cplusplus
}
#endif


#endif /* __SAMSUNG_SYSLSI_APDEV_PERFORMANCE_H__ */

